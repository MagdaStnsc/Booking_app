import React, { Component } from "react";
import { Jumbotron, Container  } from "react-bootstrap";
import './RestList.css';


class JumbotronRest extends Component {
    render() {
      return (
        <Jumbotron fluid className="mb-0 jumbotron-rest">
            <Container >

            </Container>
      </Jumbotron>
      );
    }
}

export default JumbotronRest;