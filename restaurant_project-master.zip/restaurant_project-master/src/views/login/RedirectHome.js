// import React from 'react';
// import {
//     BrowserRouter as Router,
//     Route,
//     Link,
//     Redirect
//   } from "react-router-dom";

// class RedirectHome extends React.Component {

//     return (
//         <Route
//           {...rest}
//           render={props =>
//             fakeAuth.isAuthenticated ? (
//               <Component {...props} />
//             ) : (
//               <Redirect
//                 to={{
//                   pathname: "/login",
//                   state: { from: props.location }
//                 }}
//               />
//             )
//           }
//         />
//       );
// }


// export default Login;